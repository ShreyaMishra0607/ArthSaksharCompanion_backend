require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

const PORT = process.env.PORT || 4000;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Health
app.get('/api/health', (req, res) => res.json({ ok: true }));

// Auth: register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Missing fields' });
    const hashed = await bcrypt.hash(password, 10);
    const result = await pool.query(
      'INSERT INTO users (name, email, password_hash) VALUES ($1,$2,$3) RETURNING id, name, email, created_at',
      [name, email, hashed]
    );
    const user = result.rows[0];
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
    res.json({ user, token });
  } catch (err) {
    if (err.code === '23505') { // unique_violation
      return res.status(400).json({ error: 'Email already exists' });
    }
    console.error(err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// Auth: login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Missing fields' });
    const result = await pool.query('SELECT id, name, email, password_hash FROM users WHERE email = $1', [email]);
    const user = result.rows[0];
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
    delete user.password_hash;
    res.json({ user, token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Middleware: auth
async function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'Unauthorized' });
  const token = auth.replace('Bearer ', '');
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const r = await pool.query('SELECT id, name, email FROM users WHERE id = $1', [payload.id]);
    if (!r.rows[0]) return res.status(401).json({ error: 'Unauthorized' });
    req.user = r.rows[0];
    next();
  } catch (err) {
    console.error(err);
    res.status(401).json({ error: 'Invalid token' });
  }
}

// Episodes
app.get('/api/episodes', async (req, res) => {
  try {
    const r = await pool.query('SELECT id, title, audio_url, duration_seconds FROM episodes ORDER BY created_at');
    res.json(r.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch episodes' });
  }
});

app.get('/api/episodes/:id', async (req, res) => {
  try {
    const r = await pool.query('SELECT id, title, audio_url, duration_seconds FROM episodes WHERE id = $1', [req.params.id]);
    if (!r.rows[0]) return res.status(404).json({ error: 'Episode not found' });
    res.json(r.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch episode' });
  }
});

// Progress
app.post('/api/progress', authMiddleware, async (req, res) => {
  try {
    const { episode_id, last_position_seconds = 0, completed = false } = req.body;
    if (!episode_id) return res.status(400).json({ error: 'Missing episode_id' });
    // upsert
    const r = await pool.query(
      `INSERT INTO listening_progress (user_id, episode_id, last_position_seconds, completed, updated_at)
       VALUES ($1,$2,$3,$4,now())
       ON CONFLICT (user_id, episode_id) DO UPDATE SET last_position_seconds = EXCLUDED.last_position_seconds, completed = EXCLUDED.completed, updated_at = now()
       RETURNING *`,
      [req.user.id, episode_id, last_position_seconds, completed]
    );
    res.json(r.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to save progress' });
  }
});

app.get('/api/progress', authMiddleware, async (req, res) => {
  try {
    const r = await pool.query(
      `SELECT lp.*, e.title, e.audio_url FROM listening_progress lp
       JOIN episodes e ON e.id = lp.episode_id
       WHERE lp.user_id = $1`,
      [req.user.id]
    );
    res.json(r.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch progress' });
  }
});

app.listen(PORT, () => {
  console.log('Server running on port', PORT);
});
